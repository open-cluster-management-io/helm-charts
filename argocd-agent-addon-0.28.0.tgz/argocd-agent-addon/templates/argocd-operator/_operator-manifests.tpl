{{- define "argocd-operator.manifests" -}}
---
apiVersion: v1
kind: Namespace
metadata:
  labels:
    control-plane: argocd-operator
    app.kubernetes.io/managed-by: argocd-agent-addon
  name: {{ .Values.global.argoCDOperatorNamespace }}
---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: argocd-operator-controller-manager
  namespace: {{ .Values.global.argoCDOperatorNamespace }}
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: argocd-operator-leader-election-role
  namespace: {{ .Values.global.argoCDOperatorNamespace }}
rules:
- apiGroups:
  - ""
  resources:
  - configmaps
  verbs:
  - get
  - list
  - watch
  - create
  - update
  - patch
  - delete
- apiGroups:
  - coordination.k8s.io
  resources:
  - leases
  verbs:
  - get
  - list
  - watch
  - create
  - update
  - patch
  - delete
- apiGroups:
  - ""
  resources:
  - events
  verbs:
  - create
  - patch
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: argocd-operator-manager-role
rules:
- apiGroups:
  - ""
  resources:
  - configmaps
  verbs:
  - '*'
- apiGroups:
  - ""
  resources:
  - endpoints
  - events
  - namespaces
  - persistentvolumeclaims
  - secrets
  - serviceaccounts
  - services
  - services/finalizers
  verbs:
  - '*'
- apiGroups:
  - ""
  resources:
  - pods
  verbs:
  - '*'
- apiGroups:
  - ""
  resources:
  - pods/log
  verbs:
  - get
- apiGroups:
  - apiregistration.k8s.io
  resources:
  - apiservices
  verbs:
  - get
  - list
- apiGroups:
  - apps
  resources:
  - daemonsets
  - deployments
  - replicasets
  - statefulsets
  verbs:
  - '*'
- apiGroups:
  - apps
  resourceNames:
  - argocd-operator
  resources:
  - deployments/finalizers
  verbs:
  - update
- apiGroups:
  - argocd-image-updater.argoproj.io
  resources:
  - imageupdaters
  - imageupdaters/finalizers
  verbs:
  - '*'
- apiGroups:
  - argoproj.io
  resources:
  - applications
  - appprojects
  - argocdexports
  - argocdexports/finalizers
  - argocdexports/status
  - argocds
  - argocds/finalizers
  - argocds/status
  - namespacemanagements
  - namespacemanagements/finalizers
  - namespacemanagements/status
  - notificationsconfigurations
  - notificationsconfigurations/finalizers
  verbs:
  - '*'
- apiGroups:
  - autoscaling
  resources:
  - horizontalpodautoscalers
  verbs:
  - '*'
- apiGroups:
  - batch
  resources:
  - cronjobs
  - jobs
  verbs:
  - '*'
- apiGroups:
  - certificates.k8s.io
  resources:
  - clustertrustbundles
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - config.openshift.io
  resources:
  - authentications
  - clusterversions
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - monitoring.coreos.com
  resources:
  - prometheuses
  - prometheusrules
  - servicemonitors
  verbs:
  - '*'
- apiGroups:
  - networking.k8s.io
  resources:
  - ingresses
  verbs:
  - '*'
- apiGroups:
  - networking.k8s.io
  resources:
  - networkpolicies
  verbs:
  - create
  - delete
  - get
  - list
  - patch
  - update
  - watch
- apiGroups:
  - oauth.openshift.io
  resources:
  - oauthclients
  verbs:
  - create
  - delete
  - get
  - list
  - patch
  - update
  - watch
- apiGroups:
  - rbac.authorization.k8s.io
  resources:
  - '*'
  - clusterrolebindings
  - clusterroles
  verbs:
  - '*'
- apiGroups:
  - route.openshift.io
  resources:
  - routes
  - routes/custom-host
  verbs:
  - '*'
- apiGroups:
  - template.openshift.io
  resources:
  - templateconfigs
  - templateinstances
  - templates
  verbs:
  - '*'
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: argocd-operator-metrics-reader
rules:
- nonResourceURLs:
  - /metrics
  verbs:
  - get
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: argocd-operator-namespacemanagement-editor-role
rules:
- apiGroups:
  - argoproj.io
  resources:
  - namespacemanagements
  verbs:
  - create
  - delete
  - get
  - list
  - patch
  - update
  - watch
- apiGroups:
  - argoproj.io
  resources:
  - namespacemanagements/status
  verbs:
  - get
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: argocd-operator-namespacemanagement-viewer-role
rules:
- apiGroups:
  - argoproj.io
  resources:
  - namespacemanagements
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - argoproj.io
  resources:
  - namespacemanagements/status
  verbs:
  - get
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: argocd-operator-proxy-role
rules:
- apiGroups:
  - authentication.k8s.io
  resources:
  - tokenreviews
  verbs:
  - create
- apiGroups:
  - authorization.k8s.io
  resources:
  - subjectaccessreviews
  verbs:
  - create
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: argocd-operator-leader-election-rolebinding
  namespace: {{ .Values.global.argoCDOperatorNamespace }}
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: argocd-operator-leader-election-role
subjects:
- kind: ServiceAccount
  name: argocd-operator-controller-manager
  namespace: {{ .Values.global.argoCDOperatorNamespace }}
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: argocd-operator-manager-rolebinding
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: argocd-operator-manager-role
subjects:
- kind: ServiceAccount
  name: argocd-operator-controller-manager
  namespace: {{ .Values.global.argoCDOperatorNamespace }}
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: argocd-operator-proxy-rolebinding
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: argocd-operator-proxy-role
subjects:
- kind: ServiceAccount
  name: argocd-operator-controller-manager
  namespace: {{ .Values.global.argoCDOperatorNamespace }}
---
apiVersion: v1
data:
  controller_manager_config.yaml: |
    apiVersion: controller-runtime.sigs.k8s.io/v1alpha1
    kind: ControllerManagerConfig
    health:
      healthProbeBindAddress: :8081
    metrics:
      bindAddress: 127.0.0.1:8080
    webhook:
      port: 9443
    leaderElection:
      leaderElect: true
      resourceName: b674928d.argoproj.io
kind: ConfigMap
metadata:
  name: argocd-operator-manager-config
  namespace: {{ .Values.global.argoCDOperatorNamespace }}
---
apiVersion: v1
kind: Service
metadata:
  labels:
    control-plane: argocd-operator
  name: argocd-operator-controller-manager-metrics-service
  namespace: {{ .Values.global.argoCDOperatorNamespace }}
spec:
  ports:
  - name: https
    port: 8443
    targetPort: 8080
  selector:
    control-plane: argocd-operator
---
apiVersion: v1
kind: Service
metadata:
  name: argocd-operator-webhook-service
  namespace: {{ .Values.global.argoCDOperatorNamespace }}
spec:
  ports:
  - port: 443
    protocol: TCP
    targetPort: 9443
  selector:
    control-plane: argocd-operator
---
apiVersion: apps/v1
kind: Deployment
metadata:
  labels:
    control-plane: argocd-operator
  name: argocd-operator-controller-manager
  namespace: {{ .Values.global.argoCDOperatorNamespace }}
spec:
  replicas: 1
  selector:
    matchLabels:
      control-plane: argocd-operator
  template:
    metadata:
      annotations:
        kubectl.kubernetes.io/default-container: manager
      labels:
        control-plane: argocd-operator
    spec:
      containers:
      - args:
        - --leader-elect
        command:
        - /manager
        env:
        - name: ARGOCD_CLUSTER_CONFIG_NAMESPACES
          value: "*"
        - name: ARGOCD_PRINCIPAL_TLS_SERVER_ALLOW_GENERATE
          value: "false"
        - name: WATCH_NAMESPACE
          valueFrom:
            fieldRef:
              fieldPath: metadata.annotations['olm.targetNamespaces']
        image: "{{ .Values.operatorImage }}:{{ .Values.operatorImageTag }}"
        livenessProbe:
          httpGet:
            path: /healthz
            port: 8081
          initialDelaySeconds: 15
          periodSeconds: 20
        name: manager
        ports:
        - containerPort: 9443
          name: webhook-server
          protocol: TCP
        readinessProbe:
          httpGet:
            path: /readyz
            port: 8081
          initialDelaySeconds: 5
          periodSeconds: 10
        securityContext:
          allowPrivilegeEscalation: false
          capabilities:
            drop:
            - ALL
          readOnlyRootFilesystem: true
          runAsNonRoot: true
          seccompProfile:
            type: RuntimeDefault
        volumeMounts:
        - mountPath: /tmp/k8s-webhook-server/serving-certs
          name: cert
          readOnly: true
      securityContext:
        runAsNonRoot: true
      serviceAccountName: argocd-operator-controller-manager
      terminationGracePeriodSeconds: 10
      volumes:
      - name: cert
        secret:
          defaultMode: 420
          optional: true
          secretName: webhook-server-cert
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: open-cluster-management:argocd-agent:work-agent-argocd
  labels:
    open-cluster-management.io/aggregate-to-work: "true"
    app.kubernetes.io/managed-by: argocd-agent-addon
rules:
- apiGroups:
  - argoproj.io
  resources:
  - argocds
  verbs:
  - get
  - list
  - watch
  - create
  - update
  - patch
  - delete
- apiGroups:
  - argoproj.io
  resources:
  - argocds/status
  verbs:
  - get
  - update
  - patch
- apiGroups:
  - argoproj.io
  resources:
  - argocds/finalizers
  verbs:
  - update
  - patch
{{- end -}}
